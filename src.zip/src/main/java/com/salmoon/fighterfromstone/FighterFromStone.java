package com.salmoon.fighterfromstone;

import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.block.entity.ModBlockEntity;
import com.salmoon.fighterfromstone.fluid.ModFluid;
import com.salmoon.fighterfromstone.item.ModItem;
import com.salmoon.fighterfromstone.itemgroup.ModItemGroup;
import com.salmoon.fighterfromstone.screen.ModScreenHandler;
import com.salmoon.fighterfromstone.util.ModLootTableModifier;
import com.salmoon.fighterfromstone.world.gen.ModWorldGeneration;
import net.fabricmc.api.ModInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FighterFromStone implements ModInitializer {
	public static final String MOD_ID = "fighterfromstone";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Hello from \"Fighter from stone\" mod");
		ModItem.registerItem();
		ModBlock.registerBlock();
		ModFluid.registerFluid();
		ModBlockEntity.registerBlockEntity();
		ModItemGroup.registerItemGroup();
		ModLootTableModifier.modifyLootTable();
		ModWorldGeneration.generateModWorldGen();
		ModScreenHandler.registerScreenHandler();
	}
}