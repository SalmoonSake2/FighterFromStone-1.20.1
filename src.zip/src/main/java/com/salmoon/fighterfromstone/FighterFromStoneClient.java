package com.salmoon.fighterfromstone;

import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.fluid.ModFluid;
import com.salmoon.fighterfromstone.screen.ModScreenHandler;
import com.salmoon.fighterfromstone.screen.RefiningMachineScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

public class FighterFromStoneClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FighterFromStone.LOGGER.info("initialize the client...");
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlock.ALUMINIUM_DOOR,RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlock.ALUMINIUM_TRAPDOOR,RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlock.HARDEN_GLASS,RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlock.FLAX_CROP,RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlock.REFINING_MACHINE,RenderLayer.getCutout());
        FluidRenderHandlerRegistry.INSTANCE.register(ModFluid.PETROLEUM,ModFluid.FLOWING_PETROLEUM,new SimpleFluidRenderHandler(
                SimpleFluidRenderHandler.WATER_STILL,SimpleFluidRenderHandler.WATER_STILL,
                0x302621
        ));
        BlockRenderLayerMap.INSTANCE.putFluids(RenderLayer.getTranslucent(),ModFluid.PETROLEUM,ModFluid.FLOWING_PETROLEUM);

        //link the handler and the screen
        HandledScreens.register(ModScreenHandler.REFINING_MACHINE_SCREEN_HANDLER, RefiningMachineScreen::new);
    }
}
