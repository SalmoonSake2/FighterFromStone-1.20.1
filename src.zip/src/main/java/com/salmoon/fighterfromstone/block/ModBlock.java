package com.salmoon.fighterfromstone.block;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.block.custom.ApproachPathIndicatorBlock;
import com.salmoon.fighterfromstone.block.custom.FlaxCropBlock;
import com.salmoon.fighterfromstone.block.custom.RefiningMachineBlock;
import com.salmoon.fighterfromstone.fluid.ModFluid;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public class ModBlock {

    public static final Block BAUXITE_BLOCK = registerNormalBlock("bauxite_block",BlockSoundGroup.TUFF,true,5.0f,4.0f);
    public static final Block ALUMINIUM_BLOCK = registerNormalBlock("aluminium_block",BlockSoundGroup.STONE,true,5.0f,6.0f);
    public static final Block CINNABAR_BLOCK = registerNormalBlock("cinnabar_block",BlockSoundGroup.TUFF,true,1.5f,6.0f);
    public static final Block HARDEN_GLASS = Registry.register(Registries.BLOCK, new Identifier(FighterFromStone.MOD_ID, "harden_glass"), new Block(FabricBlockSettings.copyOf(Blocks.GLASS).strength(5.0f).resistance(30.0f)));
    public static final Block ALUMINIUM_STAIRS = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"aluminium_stairs"),new StairsBlock(ModBlock.ALUMINIUM_BLOCK.getDefaultState(),FabricBlockSettings.copyOf(ModBlock.ALUMINIUM_BLOCK)));
    public static final Block ALUMINIUM_SLAB = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"aluminium_slab"),new SlabBlock(FabricBlockSettings.copyOf(ModBlock.ALUMINIUM_BLOCK)));
    public static final Block ALUMINIUM_WALL = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"aluminium_wall"),new WallBlock(FabricBlockSettings.copyOf(ModBlock.ALUMINIUM_BLOCK)));
    // nonOpaque() 無-不透明度 when your reference block is not a door or trapdoor
    public static final Block ALUMINIUM_DOOR = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"aluminium_door"),new DoorBlock(FabricBlockSettings.copyOf(Blocks.IRON_DOOR),BlockSetType.IRON));
    public static final Block ALUMINIUM_TRAPDOOR = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"aluminium_trapdoor"),new TrapdoorBlock(FabricBlockSettings.copyOf(Blocks.IRON_TRAPDOOR),BlockSetType.IRON));
    public static final Block FLAX_CROP = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"flax_crop"),new FlaxCropBlock(FabricBlockSettings.copyOf(Blocks.WHEAT)));
    public static final Block PETROLEUM = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"petroleum"),new FluidBlock(ModFluid.PETROLEUM, AbstractBlock.Settings.create().mapColor(MapColor.BLACK).replaceable().noCollision().strength(100.0f).pistonBehavior(PistonBehavior.DESTROY).dropsNothing().liquid().sounds(BlockSoundGroup.INTENTIONALLY_EMPTY)));
    public static final Block REFINING_MACHINE = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"refining_machine"),new RefiningMachineBlock(FabricBlockSettings.copyOf(Blocks.IRON_BLOCK).nonOpaque()));
    public static final Block ASPHALT_BLOCK = registerNormalBlock("asphalt_block",BlockSoundGroup.TUFF,true,1.5f,3.0f);
    public static final Block APPROACH_PATH_INDICATOR = Registry.register(Registries.BLOCK,new Identifier(FighterFromStone.MOD_ID,"approach_path_indicator"),new ApproachPathIndicatorBlock(FabricBlockSettings.create().strength(1.0f).resistance(3.0f).nonOpaque()));
    public static Block registerNormalBlock(String id, BlockSoundGroup soundGroup,boolean requireTools,float hardness,float resistance){
        if (requireTools) {
            return Registry.register(Registries.BLOCK, new Identifier(FighterFromStone.MOD_ID, id), new Block(FabricBlockSettings.create().requiresTool().sounds(soundGroup).hardness(hardness).resistance(resistance)));
        }
        else{
            return Registry.register(Registries.BLOCK, new Identifier(FighterFromStone.MOD_ID, id), new Block(FabricBlockSettings.create().sounds(soundGroup).hardness(hardness).resistance(resistance)));
        }
    }

    public static void registerBlock(){
        FighterFromStone.LOGGER.info("registering blocks");
    }
}
