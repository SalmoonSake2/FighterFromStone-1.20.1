package com.salmoon.fighterfromstone.block.entity;


import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.block.ModBlock;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlockEntity {
    public static final BlockEntityType<RefiningMachineBlockEntity> REFINING_MACHINE_BLOCK_ENTITY_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE,new Identifier(FighterFromStone.MOD_ID,"refining_machine_be"), FabricBlockEntityTypeBuilder.create(RefiningMachineBlockEntity::new, ModBlock.REFINING_MACHINE).build());

    public static void registerBlockEntity(){
        FighterFromStone.LOGGER.info("register block entity");
    }
}
