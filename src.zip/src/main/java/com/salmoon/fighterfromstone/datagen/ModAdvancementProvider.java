package com.salmoon.fighterfromstone.datagen;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.item.ModItem;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.AdvancementFrame;
import net.minecraft.advancement.criterion.*;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.function.Consumer;

public class ModAdvancementProvider extends FabricAdvancementProvider {
    public ModAdvancementProvider(FabricDataOutput output) {
        super(output);
    }
    @Override
    public void generateAdvancement(Consumer<Advancement> consumer) {
        Advancement rootAdvancement = Advancement.Builder.create()
                .display(
                        ModItem.WOODEN_AIRPLANE_BLUEPRINT,
                        Text.translatable("advancement.fighterfromstone.root.title"),
                        Text.translatable("advancement.fighterfromstone.root.description"),
                        new Identifier(FighterFromStone.MOD_ID,"textures/block/aluminium_block.png"),
                        AdvancementFrame.TASK,
                        false,
                        false,
                        false
                )
                .criterion("fighterfromstone_root",TickCriterion.Conditions.createTick())
                .build(consumer,FighterFromStone.MOD_ID+"/root");

        Advancement getFlaxSeedAdvancement = createAdvancement(rootAdvancement,ModItem.FLAX_SEED,
                "advancement.fighterfromstone.get_flax_seed.title",
                "advancement.fighterfromstone.get_flax_seed.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_flax_seed", InventoryChangedCriterion.Conditions.items(ModItem.FLAX_SEED))
                .build(consumer,FighterFromStone.MOD_ID+"/get_flax_seed");
//        Advancement getFlaxFabricAdvancement = createAdvancement(getFlaxSeedAdvancement,ModItem.FLAX_FABRIC,
//                "advancement.fighterfromstone.get_flax_fabric.title",
//                "advancement.fighterfromstone.get_flax_fabric.description",
//                AdvancementFrame.TASK,true,false)
//                .criterion("get_flax_fabric", InventoryChangedCriterion.Conditions.items(ModItem.FLAX_FABRIC))
//                .build(consumer,FighterFromStone.MOD_ID+"/get_flax_fabric");
        Advancement getBomberJacketAdvancement = createAdvancement(getFlaxSeedAdvancement,ModItem.BOMBER_JACKET_TRAIN,
                "advancement.fighterfromstone.get_bomber_jacket.title",
                "advancement.fighterfromstone.get_bomber_jacket.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_bomber_jacket",InventoryChangedCriterion.Conditions.items(ModItem.BOMBER_JACKET_TRAIN,ModItem.BOMBER_HELMET_TRAIN,ModItem.BOMBER_PANTS_TRAIN))
                .build(consumer,FighterFromStone.MOD_ID+"/get_bomber_jacket");
        Advancement getBauxiteAdvancement = createAdvancement(rootAdvancement,ModItem.BAUXITE_BLOCK,
                "advancement.fighterfromstone.get_bauxite.title",
                "advancement.fighterfromstone.get_bauxite.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_bauxite",InventoryChangedCriterion.Conditions.items(ModItem.BAUXITE))
                .build(consumer,FighterFromStone.MOD_ID+"/get_bauxite");
        Advancement getCinnabarAdvancement = createAdvancement(getBauxiteAdvancement,ModItem.CINNABAR_BLOCK,
                "advancement.fighterfromstone.get_cinnabar.title",
                "advancement.fighterfromstone.get_cinnabar.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_cinnabar",InventoryChangedCriterion.Conditions.items(ModItem.CINNABAR))
                .build(consumer,FighterFromStone.MOD_ID+"/get_cinnabar");
        Advancement getAluminiumIngotAdvancement = createAdvancement(getCinnabarAdvancement,ModItem.ALUMINIUM_INGOT,
                "advancement.fighterfromstone.get_aluminium_ingot.title",
                "advancement.fighterfromstone.get_aluminium_ingot.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_aluminium_ingot",InventoryChangedCriterion.Conditions.items(ModItem.ALUMINIUM_INGOT))
                .build(consumer,FighterFromStone.MOD_ID+"/get_aluminium_ingot");
        Advancement getWoodenBluePrintAdvancement = createAdvancement(getAluminiumIngotAdvancement,ModItem.WOODEN_AIRPLANE_BLUEPRINT,
                "advancement.fighterfromstone.get_wooden_airplane_blueprint.title",
                "advancement.fighterfromstone.get_wooden_airplane_blueprint.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_wooden_airplane_blueprint",InventoryChangedCriterion.Conditions.items(ModItem.WOODEN_AIRPLANE_BLUEPRINT))
                .build(consumer,FighterFromStone.MOD_ID+"/get_wooden_airplane_blueprint");
        Advancement getPetroleumBucketAdvancement = createAdvancement(getAluminiumIngotAdvancement,ModItem.PETROLEUM_BUCKET,
                "advancement.fighterfromstone.get_petroleum_bucket.title",
                "advancement.fighterfromstone.get_petroleum_bucket.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_petroleum_bucket",InventoryChangedCriterion.Conditions.items(ModItem.PETROLEUM_BUCKET))
                .build(consumer,FighterFromStone.MOD_ID+"/get_petroleum_bucket");
        Advancement sinkPetroleumAdvancement = createAdvancement(getPetroleumBucketAdvancement,ModItem.PETROLEUM_BUCKET,
                "advancement.fighterfromstone.sink_petroleum.title",
                "advancement.fighterfromstone.sink_petroleum.description",
                AdvancementFrame.GOAL,true,true)
                .criterion("sink_petroleum", EnterBlockCriterion.Conditions.block(ModBlock.PETROLEUM))
                .build(consumer,FighterFromStone.MOD_ID+"/sink_petroleum");
        Advancement getFlaxOilAdvancement = createAdvancement(getFlaxSeedAdvancement,ModItem.FLAX_OIL,
                "advancement.fighterfromstone.get_flax_oil.title",
                "advancement.fighterfromstone.get_flax_oil.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_flax_oil",InventoryChangedCriterion.Conditions.items(ModItem.FLAX_OIL))
                .build(consumer,FighterFromStone.MOD_ID+"/get_flax_oil");
        Advancement getFuelBucketAdvancement = createAdvancement(getPetroleumBucketAdvancement,ModItem.FUEL_BUCKET,
                "advancement.fighterfromstone.get_fuel_bucket.title",
                "advancement.fighterfromstone.get_fuel_bucket.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_fuel_bucket",InventoryChangedCriterion.Conditions.items(ModItem.FUEL_BUCKET))
                .build(consumer,FighterFromStone.MOD_ID+"/get_fuel_bucket");
        Advancement getAsphaltAdvancement = createAdvancement(getPetroleumBucketAdvancement,ModItem.ASPHALT,
                "advancement.fighterfromstone.get_asphalt.title",
                "advancement.fighterfromstone.get_asphalt.description",
                AdvancementFrame.TASK,true,false)
                .criterion("get_asphalt",InventoryChangedCriterion.Conditions.items(ModItem.ASPHALT))
                .build(consumer,FighterFromStone.MOD_ID+"/get_asphalt");
    }

    private Advancement.Builder createAdvancement(Advancement parent, Item icon, String title_path, String description_path, AdvancementFrame frame, boolean show, boolean hidden){
        return Advancement.Builder.create().parent(parent).display(icon, Text.translatable(title_path), Text.translatable(description_path), null, frame, show, show, hidden);
    }
}
