package com.salmoon.fighterfromstone.datagen;

import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.item.ModItem;
import com.salmoon.fighterfromstone.util.ModTag;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;

import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {

    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(RegistryWrapper.WrapperLookup arg) {
        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
                .add(ModBlock.ALUMINIUM_BLOCK)
                .add(ModBlock.CINNABAR_BLOCK)
                .add(ModBlock.BAUXITE_BLOCK)
                .add(ModBlock.ALUMINIUM_STAIRS)
                .add(ModBlock.ALUMINIUM_SLAB)
                .add(ModBlock.ALUMINIUM_WALL)
                .add(ModBlock.ALUMINIUM_DOOR)
                .add(ModBlock.ALUMINIUM_TRAPDOOR)
                .add(ModBlock.ASPHALT_BLOCK);

        getOrCreateTagBuilder(BlockTags.NEEDS_STONE_TOOL)
                .add(ModBlock.CINNABAR_BLOCK)
                .add(ModBlock.ASPHALT_BLOCK);

        getOrCreateTagBuilder(BlockTags.NEEDS_IRON_TOOL)
                .add(ModBlock.ALUMINIUM_BLOCK)
                .add(ModBlock.BAUXITE_BLOCK)
                .add(ModBlock.ALUMINIUM_STAIRS)
                .add(ModBlock.ALUMINIUM_SLAB)
                .add(ModBlock.ALUMINIUM_WALL)
                .add(ModBlock.ALUMINIUM_DOOR)
                .add(ModBlock.ALUMINIUM_TRAPDOOR);
        getOrCreateTagBuilder(BlockTags.WALLS)
                .add(ModBlock.ALUMINIUM_WALL);
        getOrCreateTagBuilder(BlockTags.DOORS)
                .add(ModBlock.ALUMINIUM_DOOR);
        getOrCreateTagBuilder(BlockTags.STAIRS)
                .add(ModBlock.ALUMINIUM_STAIRS);
        getOrCreateTagBuilder(BlockTags.SLABS)
                .add(ModBlock.ALUMINIUM_SLAB);
        getOrCreateTagBuilder(BlockTags.TRAPDOORS)
                .add(ModBlock.ALUMINIUM_TRAPDOOR);

        getOrCreateTagBuilder(ModTag.Blocks.BauxiteReplaceable)
                .add(Blocks.RED_SAND)
                .add(Blocks.RED_SANDSTONE);
    }
}
