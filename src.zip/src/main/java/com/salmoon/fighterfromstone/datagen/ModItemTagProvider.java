package com.salmoon.fighterfromstone.datagen;

import com.salmoon.fighterfromstone.item.ModItem;
import com.salmoon.fighterfromstone.util.ModTag;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryWrapper;
import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    //這邊會有兩種可能匯入的來源，要注意
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void configure(RegistryWrapper.WrapperLookup arg) {
        getOrCreateTagBuilder(ModTag.Items.AIRPLANE_FUEL)
                .add(Items.HONEY_BOTTLE)
                .add(ModItem.FUEL_BUCKET);

    }
}
