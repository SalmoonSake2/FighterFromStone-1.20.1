package com.salmoon.fighterfromstone.datagen;

import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.block.custom.FlaxCropBlock;
import com.salmoon.fighterfromstone.item.ModItem;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.data.client.BlockStateModelGenerator;
import net.minecraft.data.server.loottable.BlockLootTableGenerator;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.loot.condition.BlockStatePropertyLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.entry.LootPoolEntry;
import net.minecraft.loot.function.ApplyBonusLootFunction;
import net.minecraft.predicate.StatePredicate;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void generate() {
        addDrop(ModBlock.ALUMINIUM_BLOCK);
        addDrop(ModBlock.ASPHALT_BLOCK);
        addDrop(ModBlock.BAUXITE_BLOCK,BlockLootTableGenerator
                .dropsWithSilkTouch(
                        ModBlock.BAUXITE_BLOCK,
                        (LootPoolEntry.Builder)this.applyExplosionDecay(
                                ModItem.BAUXITE_BLOCK,
                                ItemEntry.builder(ModItem.BAUXITE)
                                        .apply(ApplyBonusLootFunction.oreDrops(Enchantments.FORTUNE))
                        )
                )
        );
        addDrop(ModBlock.HARDEN_GLASS,dropsWithSilkTouch(ModItem.HARDEN_GLASS));
        addDrop(ModBlock.CINNABAR_BLOCK,BlockLootTableGenerator
                .dropsWithSilkTouch(
                        ModBlock.CINNABAR_BLOCK,
                        (LootPoolEntry.Builder)this.applyExplosionDecay(
                                ModItem.CINNABAR_BLOCK,
                                ItemEntry.builder(ModItem.CINNABAR)
                                        .apply(ApplyBonusLootFunction.oreDrops(Enchantments.FORTUNE))
                        )
                )
        );
        addDrop(ModBlock.ALUMINIUM_STAIRS,drops(ModItem.ALUMINIUM_STAIRS));
        addDrop(ModBlock.ALUMINIUM_SLAB,slabDrops(ModBlock.ALUMINIUM_SLAB));
        addDrop(ModBlock.ALUMINIUM_WALL,drops(ModItem.ALUMINIUM_WALL));
        addDrop(ModBlock.ALUMINIUM_DOOR,doorDrops(ModBlock.ALUMINIUM_DOOR));
        addDrop(ModBlock.ALUMINIUM_TRAPDOOR,drops(ModItem.ALUMINIUM_TRAPDOOR));
        addDrop(ModBlock.APPROACH_PATH_INDICATOR,drops(ModItem.APPROACH_PATH_INDICATOR));

        BlockStatePropertyLootCondition.Builder flax_cbuilder = BlockStatePropertyLootCondition.builder(ModBlock.FLAX_CROP)
                .properties(StatePredicate.Builder.create().exactMatch(FlaxCropBlock.AGE,6));
        addDrop(ModBlock.FLAX_CROP,cropDrops(ModBlock.FLAX_CROP,ModItem.FLAX_FABRIC,ModItem.FLAX_SEED,flax_cbuilder));

    }
}
