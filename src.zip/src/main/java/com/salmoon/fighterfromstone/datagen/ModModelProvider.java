package com.salmoon.fighterfromstone.datagen;

import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.block.custom.FlaxCropBlock;
import com.salmoon.fighterfromstone.item.ModItem;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.data.client.BlockStateModelGenerator;
import net.minecraft.data.client.ItemModelGenerator;
import net.minecraft.data.client.Model;
import net.minecraft.data.client.Models;
import net.minecraft.item.ArmorItem;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(BlockStateModelGenerator blockStateModelGenerator) {
        blockStateModelGenerator.registerSimpleCubeAll(ModBlock.CINNABAR_BLOCK);
        BlockStateModelGenerator.BlockTexturePool aluminium_pool = blockStateModelGenerator.registerCubeAllModelTexturePool(ModBlock.ALUMINIUM_BLOCK);
        aluminium_pool.stairs(ModBlock.ALUMINIUM_STAIRS);
        aluminium_pool.slab(ModBlock.ALUMINIUM_SLAB);
        aluminium_pool.wall(ModBlock.ALUMINIUM_WALL);
        blockStateModelGenerator.registerDoor(ModBlock.ALUMINIUM_DOOR);
        blockStateModelGenerator.registerTrapdoor(ModBlock.ALUMINIUM_TRAPDOOR);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlock.BAUXITE_BLOCK);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlock.HARDEN_GLASS);

        //this method would also register the seed item model!
        blockStateModelGenerator.registerCrop(ModBlock.FLAX_CROP, FlaxCropBlock.AGE,0,1,2,3,4,5,6);

        blockStateModelGenerator.registerNorthDefaultHorizontalRotation(ModBlock.REFINING_MACHINE);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlock.ASPHALT_BLOCK);
        blockStateModelGenerator.registerNorthDefaultHorizontalRotation(ModBlock.APPROACH_PATH_INDICATOR);
    }

    @Override
    public void generateItemModels(ItemModelGenerator itemModelGenerator) {
        itemModelGenerator.register(ModItem.ALUMINIUM_INGOT, Models.GENERATED);
        itemModelGenerator.register(ModItem.ALUMINIUM_PLATE, Models.GENERATED);
        itemModelGenerator.register(ModItem.CLOTH, Models.GENERATED);
        itemModelGenerator.register(ModItem.FUEL_BUCKET, Models.GENERATED);
        itemModelGenerator.register(ModItem.BAUXITE, Models.GENERATED);
        itemModelGenerator.register(ModItem.CINNABAR, Models.GENERATED);
        itemModelGenerator.register(ModItem.FLAX_FABRIC, Models.GENERATED);
        itemModelGenerator.register(ModItem.ROPE,Models.GENERATED);
        itemModelGenerator.register(ModItem.PETROLEUM_BUCKET, Models.GENERATED);
        itemModelGenerator.register(ModItem.PISTON_ENGINE, Models.GENERATED);
        itemModelGenerator.register(ModItem.PROPELLER, Models.GENERATED);
        itemModelGenerator.register(ModItem.ROCKY_SOIL, Models.GENERATED);
        itemModelGenerator.register(ModItem.WOODEN_AIRPLANE_BLUEPRINT,Models.GENERATED);
        itemModelGenerator.registerArmor((ArmorItem) ModItem.BOMBER_HELMET_TRAIN);
        itemModelGenerator.registerArmor((ArmorItem) ModItem.BOMBER_JACKET_TRAIN);
        itemModelGenerator.registerArmor((ArmorItem) ModItem.BOMBER_PANTS_TRAIN);
        itemModelGenerator.register(ModItem.THICK_LEATHER,Models.GENERATED);
        itemModelGenerator.register(ModItem.FLAX_OIL,Models.GENERATED);
        itemModelGenerator.register(ModItem.ASPHALT,Models.GENERATED);
    }
}
