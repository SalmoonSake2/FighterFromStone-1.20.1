package com.salmoon.fighterfromstone.datagen;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.item.ModItem;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.data.server.recipe.*;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.ShapelessRecipe;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.function.Consumer;

public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generate(Consumer<RecipeJsonProvider> exporter) {
        CookingRecipeJsonBuilder.create(Ingredient.ofItems(ModItem.BAUXITE),RecipeCategory.MISC,ModItem.ROCKY_SOIL,
                0.7f, 200, RecipeSerializer.BLASTING).group("rocky_soil")
                .criterion(RecipeProvider.hasItem(ModItem.BAUXITE), RecipeProvider.conditionsFromItem(ModItem.BAUXITE))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,"rocky_soil_from_bauxite_blasting"));

        CookingRecipeJsonBuilder.create(Ingredient.ofItems(ModItem.BAUXITE),RecipeCategory.MISC,ModItem.ROCKY_SOIL,
                        0.7f, 100, RecipeSerializer.SMELTING).group("rocky_soil")
                .criterion(RecipeProvider.hasItem(ModItem.BAUXITE), RecipeProvider.conditionsFromItem(ModItem.BAUXITE))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,"rocky_soil_from_bauxite_smelting"));

        CookingRecipeJsonBuilder.create(Ingredient.ofItems(ModItem.BAUXITE_BLOCK),RecipeCategory.MISC,ModItem.ROCKY_SOIL,
                        0.7f, 200, RecipeSerializer.BLASTING).group("rocky_soil")
                .criterion(RecipeProvider.hasItem(ModItem.BAUXITE_BLOCK), RecipeProvider.conditionsFromItem(ModItem.BAUXITE_BLOCK))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,"rocky_soil_from_bauxite_block_blasting"));

        CookingRecipeJsonBuilder.create(Ingredient.ofItems(ModItem.BAUXITE_BLOCK),RecipeCategory.MISC,ModItem.ROCKY_SOIL,
                        0.7f, 100, RecipeSerializer.SMELTING).group("rocky_soil")
                .criterion(RecipeProvider.hasItem(ModItem.BAUXITE_BLOCK), RecipeProvider.conditionsFromItem(ModItem.BAUXITE_BLOCK))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,"rocky_soil_from_bauxite_block_smelting"));

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS,ModItem.ALUMINIUM_BLOCK,1)
                .pattern("AAA")
                .pattern("AAA")
                .pattern("AAA")
                .input('A',ModItem.ALUMINIUM_INGOT)
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ALUMINIUM_BLOCK)));

        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.ALUMINIUM_INGOT,1)
                .input(ModItem.ALUMINIUM_BLOCK,1)
                .group("aluminium_ingot")
                .criterion(hasItem(ModItem.ALUMINIUM_BLOCK),conditionsFromItem(ModItem.ALUMINIUM_BLOCK))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,"aluminium_ingot_from_aluminium_block"));

        ShapedRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.ALUMINIUM_PLATE,1)
                .pattern("   ")
                .pattern("AA ")
                .pattern("   ")
                .input('A',ModItem.ALUMINIUM_INGOT)
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ALUMINIUM_PLATE)));

        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.ALUMINIUM_INGOT,1)
                .input(ModItem.ROCKY_SOIL,1)
                .input(ModItem.CINNABAR,1)
                .input(Items.LAVA_BUCKET,1)
                .input(Items.CHARCOAL,1)
                .group("aluminium_ingot")
                .criterion(hasItem(ModItem.ROCKY_SOIL),conditionsFromItem(ModItem.ROCKY_SOIL))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,"aluminium_ingot_from_maglav_method"));

        createStairsRecipe(ModItem.ALUMINIUM_STAIRS, Ingredient.ofItems(ModItem.ALUMINIUM_INGOT))
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ALUMINIUM_STAIRS)));

        createSlabRecipe(RecipeCategory.BUILDING_BLOCKS,ModItem.ALUMINIUM_SLAB,Ingredient.ofItems(ModItem.ALUMINIUM_SLAB))
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ALUMINIUM_SLAB)));

        createTrapdoorRecipe(ModItem.ALUMINIUM_TRAPDOOR,Ingredient.ofItems(ModItem.ALUMINIUM_INGOT))
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ALUMINIUM_TRAPDOOR)));

        createDoorRecipe(ModItem.ALUMINIUM_DOOR,Ingredient.ofItems(ModItem.ALUMINIUM_INGOT))
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ALUMINIUM_DOOR)));

        offerWallRecipe(exporter,RecipeCategory.BUILDING_BLOCKS,ModItem.ALUMINIUM_WALL,ModItem.ALUMINIUM_INGOT);

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS,ModItem.HARDEN_GLASS,1)
                .pattern(" A ")
                .pattern("AGA")
                .pattern(" A ")
                .input('A',ModItem.ALUMINIUM_INGOT)
                .input('G',Items.GLASS)
                .criterion(hasItem(ModItem.ALUMINIUM_INGOT),conditionsFromItem(ModItem.ALUMINIUM_INGOT))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.HARDEN_GLASS)));

        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.THICK_LEATHER,1)
                .input(Ingredient.ofItems(ModItem.CLOTH),1)
                .input(Ingredient.ofItems(Items.LEATHER),1)
                .criterion(RecipeProvider.hasItem(Items.LEATHER),RecipeProvider.conditionsFromItem(Items.LEATHER))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.THICK_LEATHER)));

        ShapedRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.ROPE,2)
                .pattern(" # ")
                .pattern(" # ")
                .pattern(" # ")
                .input('#',ModItem.FLAX_FABRIC)
                .criterion(hasItem(ModItem.FLAX_FABRIC),conditionsFromItem(ModItem.FLAX_FABRIC))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ROPE)));

        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT,ModItem.BOMBER_HELMET_TRAIN,1)
                .pattern("###")
                .pattern("# #")
                .pattern("   ")
                .input('#',ModItem.THICK_LEATHER)
                .criterion(hasItem(ModItem.THICK_LEATHER),conditionsFromItem(ModItem.THICK_LEATHER))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.BOMBER_HELMET_TRAIN)));

        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT,ModItem.BOMBER_JACKET_TRAIN,1)
                .pattern("# #")
                .pattern("###")
                .pattern("###")
                .input('#',ModItem.THICK_LEATHER)
                .criterion(hasItem(ModItem.THICK_LEATHER),conditionsFromItem(ModItem.THICK_LEATHER))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.BOMBER_JACKET_TRAIN)));

        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT,ModItem.BOMBER_PANTS_TRAIN,1)
                .pattern("###")
                .pattern("# #")
                .pattern("# #")
                .input('#',ModItem.THICK_LEATHER)
                .criterion(hasItem(ModItem.THICK_LEATHER),conditionsFromItem(ModItem.THICK_LEATHER))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.BOMBER_PANTS_TRAIN)));

        ShapedRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.CLOTH,1)
                .pattern("###")
                .pattern("###")
                .pattern("###")
                .input('#',ModItem.FLAX_FABRIC)
                .criterion(hasItem(ModItem.FLAX_FABRIC),conditionsFromItem(ModItem.FLAX_FABRIC))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.CLOTH)));

        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC,Items.RED_DYE,1)
                .input(ModItem.CINNABAR,1)
                .group("red_dye")
                .criterion(hasItem(ModItem.CINNABAR),conditionsFromItem(ModItem.CINNABAR))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,"red_dye_from_cinnabar"));

        ShapelessRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.FLAX_OIL,1)
                .input(ModItem.FLAX_SEED,6)
                .input(Items.GLASS_BOTTLE,1)
                .group("flax_oil")
                .criterion(hasItem(ModItem.FLAX_SEED),conditionsFromItem(ModItem.FLAX_SEED))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.FLAX_OIL)));

        ShapedRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.REFINING_MACHINE,1)
                .pattern("CCC")
                .pattern("GFG")
                .pattern("SSS")
                .input('C',Items.COPPER_INGOT)
                .input('S',Items.STONE)
                .input('G',Items.GLASS_BOTTLE)
                .input('F',Items.FURNACE)
                .criterion(hasItem(ModItem.PETROLEUM_BUCKET),conditionsFromItem(ModItem.PETROLEUM_BUCKET))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.REFINING_MACHINE)));

        CookingRecipeJsonBuilder.create(Ingredient.ofItems(ModItem.PETROLEUM_BUCKET),RecipeCategory.MISC,ModItem.ASPHALT,
                        0.1f, 200, RecipeSerializer.BLASTING).group("asphalt")
                .criterion(RecipeProvider.hasItem(ModItem.PETROLEUM_BUCKET), RecipeProvider.conditionsFromItem(ModItem.PETROLEUM_BUCKET))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,"asphalt_from_blasting"));

        CookingRecipeJsonBuilder.create(Ingredient.ofItems(ModItem.PETROLEUM_BUCKET),RecipeCategory.MISC,ModItem.ASPHALT,
                        0.1f, 100, RecipeSerializer.SMELTING).group("asphalt")
                .criterion(RecipeProvider.hasItem(ModItem.PETROLEUM_BUCKET), RecipeProvider.conditionsFromItem(ModItem.PETROLEUM_BUCKET))
                .offerTo(exporter,new Identifier(FighterFromStone.MOD_ID,"asphalt_from_smelting"));

        ShapedRecipeJsonBuilder.create(RecipeCategory.MISC,ModItem.ASPHALT_BLOCK,1)
                .pattern("###")
                .pattern("###")
                .pattern("###")
                .input('#',ModItem.ASPHALT)
                .criterion(hasItem(ModItem.ASPHALT),conditionsFromItem(ModItem.ASPHALT))
                .offerTo(exporter, new Identifier(FighterFromStone.MOD_ID,getRecipeName(ModItem.ASPHALT_BLOCK)));
        }

}
