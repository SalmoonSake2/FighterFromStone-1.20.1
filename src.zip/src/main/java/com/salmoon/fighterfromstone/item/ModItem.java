package com.salmoon.fighterfromstone.item;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.fluid.ModFluid;
import com.salmoon.fighterfromstone.item.custom.FlaxOilItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import static net.minecraft.item.Items.BUCKET;
import static net.minecraft.item.Items.GLASS_BOTTLE;

public class ModItem {
    public static final Item BAUXITE = registerNormalItemFromID("bauxite");
    public static final Item ROCKY_SOIL = registerNormalItemFromID("rocky_soil");
    public static final Item ALUMINIUM_INGOT = registerNormalItemFromID("aluminium_ingot");
    public static final Item ALUMINIUM_PLATE = registerNormalItemFromID("aluminium_plate");
    public static final Item CINNABAR = registerNormalItemFromID("cinnabar");

    //AliasedItem 可以讓物品和方塊擁有不同屬性，使其的翻譯名字不會變成flax crop而是flax seed
    public static final Item FLAX_SEED = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"flax_seed"),new AliasedBlockItem(ModBlock.FLAX_CROP,new FabricItemSettings()));
    public static final Item FLAX_FABRIC = registerNormalItemFromID("flax_fabric");
    public static final Item CLOTH = registerNormalItemFromID("cloth");
    public static final Item ROPE = registerNormalItemFromID("rope");
    public static final Item PROPELLER = registerNormalItemFromID("propeller");
    public static final Item WOODEN_AIRPLANE_BLUEPRINT = registerNormalItemFromID("wooden_airplane_blueprint");
    public static final Item PETROLEUM_BUCKET = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"petroleum_bucket"), (Item)new BucketItem(ModFluid.PETROLEUM, new Item.Settings().recipeRemainder(BUCKET).maxCount(1)));
    public static final Item FUEL_BUCKET = registerNormalItemFromID("fuel_bucket");
    public static final Item PISTON_ENGINE = registerNormalItemFromID("piston_engine");
    public static final Item BOMBER_HELMET_TRAIN = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"bomber_helmet_train"),new ArmorItem(ModArmorMaterial.THICK_LEATHER,ArmorItem.Type.HELMET,new FabricItemSettings()));
    public static final Item BOMBER_JACKET_TRAIN = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"bomber_jacket_train"),new ArmorItem(ModArmorMaterial.THICK_LEATHER,ArmorItem.Type.CHESTPLATE,new FabricItemSettings()));
    public static final Item BOMBER_PANTS_TRAIN = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"bomber_pants_train"),new ArmorItem(ModArmorMaterial.THICK_LEATHER,ArmorItem.Type.LEGGINGS,new FabricItemSettings()));
    public static final Item THICK_LEATHER = registerNormalItemFromID("thick_leather");
    public static final Item ASPHALT = registerNormalItemFromID("asphalt");
    public static final Item FLAX_OIL = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"flax_oil"),new FlaxOilItem(new Item.Settings().recipeRemainder(GLASS_BOTTLE).food(FoodComponents.HONEY_BOTTLE).maxCount(1)));
    public static final Item BAUXITE_BLOCK = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"bauxite_block"), new BlockItem(ModBlock.BAUXITE_BLOCK,new FabricItemSettings()));
    public static final Item ALUMINIUM_BLOCK = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"aluminium_block"), new BlockItem(ModBlock.ALUMINIUM_BLOCK,new FabricItemSettings()));
    public static final Item CINNABAR_BLOCK = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"cinnabar_block"), new BlockItem(ModBlock.CINNABAR_BLOCK,new FabricItemSettings()));
    public static final Item HARDEN_GLASS = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"harden_glass"), new BlockItem(ModBlock.HARDEN_GLASS,new FabricItemSettings()));
    public static final Item ALUMINIUM_STAIRS = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"aluminium_stairs"), new BlockItem(ModBlock.ALUMINIUM_STAIRS,new FabricItemSettings()));
    public static final Item ALUMINIUM_SLAB = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"aluminium_slab"), new BlockItem(ModBlock.ALUMINIUM_SLAB,new FabricItemSettings()));
    public static final Item ALUMINIUM_WALL = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"aluminium_wall"), new BlockItem(ModBlock.ALUMINIUM_WALL,new FabricItemSettings()));
    public static final Item ALUMINIUM_DOOR = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"aluminium_door"), new BlockItem(ModBlock.ALUMINIUM_DOOR,new FabricItemSettings()));
    public static final Item ALUMINIUM_TRAPDOOR = Registry.register(Registries.ITEM, new Identifier(FighterFromStone.MOD_ID,"aluminium_trapdoor"), new BlockItem(ModBlock.ALUMINIUM_TRAPDOOR,new FabricItemSettings()));
    public static final Item REFINING_MACHINE = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"refining_machine"),new BlockItem(ModBlock.REFINING_MACHINE,new FabricItemSettings()));
    public static final Item ASPHALT_BLOCK = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"asphalt_block"),new BlockItem(ModBlock.ASPHALT_BLOCK,new FabricItemSettings()));
    public static final Item APPROACH_PATH_INDICATOR = Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,"approach_path_indicator"),new BlockItem(ModBlock.APPROACH_PATH_INDICATOR,new FabricItemSettings()));

    public static Item registerNormalItemFromID(String id){
        return Registry.register(Registries.ITEM,new Identifier(FighterFromStone.MOD_ID,id),new Item(new FabricItemSettings()));
    }

    public static void registerItem(){
        FighterFromStone.LOGGER.info("registering items");
        FighterFromStone.LOGGER.info("registering fuels");
        FuelRegistry.INSTANCE.add(FLAX_OIL,1600);
        FuelRegistry.INSTANCE.add(PETROLEUM_BUCKET,1280);
        FuelRegistry.INSTANCE.add(FUEL_BUCKET,20000);
    }
}
