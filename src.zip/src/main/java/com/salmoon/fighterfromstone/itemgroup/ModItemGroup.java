package com.salmoon.fighterfromstone.itemgroup;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.item.ModItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemGroup {
    public static final ItemGroup FIGHTERFROMSTONE = FabricItemGroup.builder()
            .icon(() -> new ItemStack(ModItem.WOODEN_AIRPLANE_BLUEPRINT))
            .displayName(Text.translatable("itemGroup.fighterfromstone.fighterfromstone_itemgroup"))
            .entries((c,entries) ->{
                entries.add(ModItem.ALUMINIUM_BLOCK);
                entries.add(ModItem.ALUMINIUM_STAIRS);
                entries.add(ModItem.ALUMINIUM_SLAB);
                entries.add(ModItem.ALUMINIUM_WALL);
                entries.add(ModItem.ALUMINIUM_DOOR);
                entries.add(ModItem.ALUMINIUM_TRAPDOOR);
                entries.add(ModItem.HARDEN_GLASS);
                entries.add(ModItem.ASPHALT_BLOCK);
                entries.add(ModItem.REFINING_MACHINE);
                entries.add(ModItem.APPROACH_PATH_INDICATOR);
                entries.add(ModItem.BAUXITE_BLOCK);
                entries.add(ModItem.CINNABAR_BLOCK);
                entries.add(ModItem.BAUXITE);
                entries.add(ModItem.ROCKY_SOIL);
                entries.add(ModItem.ALUMINIUM_INGOT);
                entries.add(ModItem.ALUMINIUM_PLATE);
                entries.add(ModItem.CINNABAR);
                entries.add(ModItem.ASPHALT);
                entries.add(ModItem.FLAX_SEED);
                entries.add(ModItem.FLAX_FABRIC);
                entries.add(ModItem.CLOTH);
                entries.add(ModItem.THICK_LEATHER);
                entries.add(ModItem.ROPE);
                entries.add(ModItem.PROPELLER);
                entries.add(ModItem.PISTON_ENGINE);
                entries.add(ModItem.WOODEN_AIRPLANE_BLUEPRINT);
                entries.add(ModItem.FLAX_OIL);
                entries.add(ModItem.FUEL_BUCKET);
                entries.add(ModItem.PETROLEUM_BUCKET);
                entries.add(ModItem.BOMBER_HELMET_TRAIN);
                entries.add(ModItem.BOMBER_JACKET_TRAIN);
                entries.add(ModItem.BOMBER_PANTS_TRAIN);
            }).build();

    public static void registerItemGroup(){
        FighterFromStone.LOGGER.info("registering item group");
        Registry.register(Registries.ITEM_GROUP,
                new Identifier(FighterFromStone.MOD_ID, "fighterfromstone_itemgroup"),
                ModItemGroup.FIGHTERFROMSTONE
        );
    }
}
