package com.salmoon.fighterfromstone.screen;

import com.salmoon.fighterfromstone.FighterFromStone;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class ModScreenHandler {
    public static final ScreenHandlerType<RefiningMachineScreenHandler> REFINING_MACHINE_SCREEN_HANDLER =
            Registry.register(Registries.SCREEN_HANDLER,new Identifier(FighterFromStone.MOD_ID,"refining"),new ExtendedScreenHandlerType<>(RefiningMachineScreenHandler::new));
    public static void registerScreenHandler(){
        FighterFromStone.LOGGER.info("register the screen handler");
    }
}
