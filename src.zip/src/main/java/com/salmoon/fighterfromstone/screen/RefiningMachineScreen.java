package com.salmoon.fighterfromstone.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.salmoon.fighterfromstone.FighterFromStone;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/*
    Screen類處理的項目主要是單純美術的部分(不包括物品本身)
 */

public class RefiningMachineScreen extends HandledScreen<RefiningMachineScreenHandler> {
    private static final Identifier TEXTURE = new Identifier(FighterFromStone.MOD_ID,"textures/gui/refining_machine.png");
    public RefiningMachineScreen(RefiningMachineScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
    }

    @Override
    protected void init() {
        super.init();
        titleX = 80;
        titleY = 5;
        playerInventoryTitleY = 72;
    }


    //繪製大背景
    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexProgram);
        RenderSystem.setShaderColor(1f,1f,1f,1f);
        RenderSystem.setShaderTexture(0,TEXTURE);
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;

        context.drawTexture(TEXTURE,x,y,0,0,backgroundWidth,backgroundHeight);
        renderProgressArrow(context,x,y);
    }

    //渲染進度條
    private void renderProgressArrow(DrawContext context, int x, int y) {
        if(handler.isCrafting()){
            // x,y參數的意義是繪製的位置(0,0位於左上)，u,v參數是參照的位置
            context.drawTexture(TEXTURE,x+79,y+35,176,14,handler.getScaleProgress(),16);
        }
    }

    private void renderFuelTimeProgress(DrawContext context,int x,int y){
        //render the fuel fire here...
    }

    //滑鼠移到特定位置的效果
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        drawMouseoverTooltip(context,mouseX,mouseY);
    }
}
