package com.salmoon.fighterfromstone.screen;

import com.salmoon.fighterfromstone.block.entity.RefiningMachineBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

//screen handler處理的是定義物品藍的位置、物品互動關係
public class RefiningMachineScreenHandler extends ScreenHandler {
    private final Inventory inventory;
    private final PropertyDelegate propertyDelegate;
    public final RefiningMachineBlockEntity blockEntity;

    public RefiningMachineScreenHandler(int syncId, PlayerInventory inventory, PacketByteBuf buf){
        this(syncId,inventory,inventory.player.getWorld().getBlockEntity(buf.readBlockPos()),
                new ArrayPropertyDelegate(3));
    }

    public RefiningMachineScreenHandler(int syncId, PlayerInventory playerInventory, BlockEntity blockEntity, PropertyDelegate arrayPropertyDelegate) {
        super(ModScreenHandler.REFINING_MACHINE_SCREEN_HANDLER,syncId);
        checkSize(((Inventory) blockEntity),3);
        this.inventory = (Inventory) blockEntity;
        inventory.onOpen(playerInventory.player);
        this.propertyDelegate = arrayPropertyDelegate;
        this.blockEntity = (RefiningMachineBlockEntity) blockEntity;

        this.addSlot(new Slot(inventory,0,56,17));
        this.addSlot(new Slot(inventory,1,116,35));
        this.addSlot(new Slot(inventory,2,56,53));

        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);

        addProperties(arrayPropertyDelegate);
    }

    public boolean isCrafting(){
        return propertyDelegate.get(0) > 0;
    }

    public int getScaleProgress(){
        int progress = this.propertyDelegate.get(0);
        int maxProgress = this.propertyDelegate.get(1);
        int progressArrowSize = 26; // width in pixel of the arrow

        return maxProgress != 0 && progress != 0 ? progress * progressArrowSize / maxProgress : 0;
    }

    //Shift Clicking method, always the same
    @Override
    public ItemStack quickMove(PlayerEntity player, int invSlot) {
        ItemStack newStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(invSlot);
        if(slot != null && slot.hasStack()){
            ItemStack originalStack = slot.getStack();
            newStack = originalStack.copy();
            if(invSlot < this.inventory.size()){
                if(!this.insertItem(originalStack,this.inventory.size(),this.slots.size(),true)){
                    return ItemStack.EMPTY;
                }
            }
            else if(!this.insertItem(originalStack,0,this.inventory.size(),false)){
                return ItemStack.EMPTY;
            }

            if(originalStack.isEmpty()){
                slot.setStack(ItemStack.EMPTY);
            }
            else{
                slot.markDirty();
            }
        }
        return newStack;
    }

    //簡單說就是檢查玩家能不能開啟這個方塊的gui，通常用距離判定
    @Override
    public boolean canUse(PlayerEntity player) {
        return this.inventory.canPlayerUse(player);
    }

    //helper method
    private void addPlayerInventory(PlayerInventory playerInventory){
        for(int i = 0;i<3;++i){
            for(int j = 0;j<9;++j){
                this.addSlot(new Slot(playerInventory,j+i*9+9,8+j*18,84+i*18));
            }
        }
    }

    private void addPlayerHotbar(PlayerInventory playerInventory){
        for(int i = 0;i <9;++i){
            this.addSlot(new Slot(playerInventory,i,8+i*18,142));
        }
    }
}
