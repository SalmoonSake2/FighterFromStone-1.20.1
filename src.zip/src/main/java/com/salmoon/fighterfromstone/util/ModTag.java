package com.salmoon.fighterfromstone.util;

import com.salmoon.fighterfromstone.FighterFromStone;
import net.minecraft.block.Block;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public class ModTag {
    public static class Items{
        public static final TagKey<Item> AIRPLANE_FUEL = createTag("airplane_fuel");
        private static TagKey<Item> createTag(String name){
            return TagKey.of(RegistryKeys.ITEM, new Identifier(FighterFromStone.MOD_ID,name));
        }
    }

    public static class Blocks{
        public static final TagKey<Block> BauxiteReplaceable = createBlockTag("bauxite_surface_replaceable");
        public static final TagKey<Fluid> PETROLEUM = createFluidTag("petroleum");
        private static TagKey<Block> createBlockTag(String name){
            return TagKey.of(RegistryKeys.BLOCK, new Identifier(FighterFromStone.MOD_ID,name));
        }

        private static TagKey<Fluid> createFluidTag(String name){
            return TagKey.of(RegistryKeys.FLUID, new Identifier(FighterFromStone.MOD_ID,name));
        }
    }
}
