package com.salmoon.fighterfromstone.world;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.block.ModBlock;
import com.salmoon.fighterfromstone.util.ModTag;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registerable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.structure.rule.BlockMatchRuleTest;
import net.minecraft.structure.rule.RuleTest;
import net.minecraft.structure.rule.TagMatchRuleTest;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.feature.*;

import java.util.List;

public class ModConfiguredFeature {
    public static final RegistryKey<ConfiguredFeature<?,?>> BAUXITE_KEY = registerKey("bauxite");
    public static final RegistryKey<ConfiguredFeature<?,?>> CINNABAR_KEY = registerKey("cinnabar");
    public static final RegistryKey<ConfiguredFeature<?,?>> OCEAN_PETROLEUM_KEY = registerKey("ocean_petroleum");

    public static void boostrap(Registerable<ConfiguredFeature<?,?>> context){
        RuleTest BauxiteSurfaceReplaceable = new TagMatchRuleTest(ModTag.Blocks.BauxiteReplaceable);
        RuleTest CinnabarReplaceable = new BlockMatchRuleTest(Blocks.NETHERRACK);
        RuleTest PetroleumReplaceable = new TagMatchRuleTest(BlockTags.MOSS_REPLACEABLE);

        List<OreFeatureConfig.Target> bauxite =
                List.of(OreFeatureConfig.createTarget(BauxiteSurfaceReplaceable, ModBlock.BAUXITE_BLOCK.getDefaultState()));
        List<OreFeatureConfig.Target> cinnabar =
                List.of(OreFeatureConfig.createTarget(CinnabarReplaceable, ModBlock.CINNABAR_BLOCK.getDefaultState()));
        List<OreFeatureConfig.Target> ocean_petroleum =
                List.of(OreFeatureConfig.createTarget(PetroleumReplaceable,ModBlock.PETROLEUM.getDefaultState()));

        register(context,BAUXITE_KEY,Feature.ORE,new OreFeatureConfig(bauxite,12));
        register(context,CINNABAR_KEY,Feature.ORE,new OreFeatureConfig(cinnabar,12));
        register(context,OCEAN_PETROLEUM_KEY,Feature.ORE,new OreFeatureConfig(ocean_petroleum,36,1f));
    }

    public static RegistryKey<ConfiguredFeature<?,?>> registerKey(String name){
        return RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE,new Identifier(FighterFromStone.MOD_ID,name));
    }

    private static <FC extends FeatureConfig,F extends Feature<FC>> void register(Registerable<ConfiguredFeature<?,?>> context, RegistryKey<ConfiguredFeature<?,?>> key, F feature, FC configuration){
        context.register(key,new ConfiguredFeature<>(feature,configuration));
    }
}
