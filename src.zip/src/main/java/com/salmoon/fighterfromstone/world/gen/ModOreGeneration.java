package com.salmoon.fighterfromstone.world.gen;

import com.salmoon.fighterfromstone.FighterFromStone;
import com.salmoon.fighterfromstone.world.ModConfiguredFeature;
import com.salmoon.fighterfromstone.world.ModPlacedFeature;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.world.gen.GenerationStep;

public class ModOreGeneration {
    public static void generateOres(){
        FighterFromStone.LOGGER.info("placing the bauxite");
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_BADLANDS),
                GenerationStep.Feature.LAKES,
                ModPlacedFeature.BAUXITE_PLACE_KEY);

        FighterFromStone.LOGGER.info("placing the cinnabar");
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                GenerationStep.Feature.UNDERGROUND_ORES,
                ModPlacedFeature.CINNABAR_PLACE_KEY);
        FighterFromStone.LOGGER.info("placing the petroleum");
        BiomeModifications.addFeature(BiomeSelectors.spawnsOneOf(EntityType.COD),
                GenerationStep.Feature.UNDERGROUND_ORES,
                ModPlacedFeature.OCEAN_PETROLEUM_PLACE_KEY);
    }
}
