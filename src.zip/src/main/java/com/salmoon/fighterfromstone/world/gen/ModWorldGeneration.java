package com.salmoon.fighterfromstone.world.gen;

import com.salmoon.fighterfromstone.FighterFromStone;

public class ModWorldGeneration {
    public static void generateModWorldGen(){
        FighterFromStone.LOGGER.info("generating the mod world ore placement");
        ModOreGeneration.generateOres();
    }
}
